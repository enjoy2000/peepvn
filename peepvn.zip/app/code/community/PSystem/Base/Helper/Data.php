<?php
/**
 * @category   PSystem
 * @package    PSystem_Base
 * @author     Pascal System <info@pascalsystem.pl>
 * @version    1.1.2
 */

/**
 * Pascal Base Helper
 * 
 * @category   PSystem
 * @package    PSystem_Base
 * @author     Pascal System <info@pascalsystem.pl>
 * @version    1.1.2
 */
class PSystem_Base_Helper_Data extends Mage_Core_Helper_Abstract {
}