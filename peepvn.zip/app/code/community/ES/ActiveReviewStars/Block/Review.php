<?php

class ES_ActiveReviewStars_Block_Review extends Mage_Core_Block_Template {

}